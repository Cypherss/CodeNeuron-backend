package com.example.codeneuron.Service.CalculateService.Dynamic;

import com.example.codeneuron.PO.GraphNode;
import com.example.codeneuron.VO.ResponseVO;

import java.util.HashMap;
import java.util.LinkedList;

public interface GraphCal {
    /**
     * 依赖紧密度计算
     * @return
     */
    public ResponseVO ClosenessCalculate();

    /**
     * 顶点个数计算
     * @return
     */
    public ResponseVO NodesCount();

    /**
     * 边个数计算
     * @return
     */
    public ResponseVO EdgesCount();

    /**
     * 连同域个数计算
     * @return
     */
    public ResponseVO ConnectedDomainCount();

    /**
     * 获取连同域
     * @return
     */
    public ResponseVO TopologyCalculate();

    /**
     * 设置连通域
     * @param threshold
     * @return
     */
    public ResponseVO setThreshold(double threshold);
}
