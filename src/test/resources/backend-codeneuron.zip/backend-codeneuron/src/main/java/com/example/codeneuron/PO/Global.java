package com.example.codeneuron.PO;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Global {
    public static List<Edge> edges=new ArrayList<Edge>();
    public static List<Node> nodes=new ArrayList<Node>();
    public static HashMap<String, LinkedList<GraphNode>> graph=new HashMap<String, LinkedList<GraphNode>>();
    public static HashMap<String,LinkedList<GraphNode>> inverseGraph=new HashMap<String, LinkedList<GraphNode>>();
    public static Node getNodeByName(String name){
        for(Node n:nodes){
            if(n.getName().equals(name)){
                return n;
            }
        }
        return null;
    }
}
