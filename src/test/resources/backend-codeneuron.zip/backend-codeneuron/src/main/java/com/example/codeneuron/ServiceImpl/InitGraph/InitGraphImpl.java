package com.example.codeneuron.ServiceImpl.InitGraph;

import com.example.codeneuron.Dao.EdgeMapper;
import com.example.codeneuron.Dao.NodeMapper;
import com.example.codeneuron.PO.Edge;
import com.example.codeneuron.PO.Global;
import com.example.codeneuron.PO.GraphNode;
import com.example.codeneuron.PO.Node;
import com.example.codeneuron.Service.InitGraph.InitGraph;
import com.example.codeneuron.VO.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedList;



@Service
public class InitGraphImpl implements InitGraph {


    NodeMapper nodeMapper;
    EdgeMapper edgeMapper;


    LinkedList<GraphNode> temp,val;
    @Autowired
    public InitGraphImpl(NodeMapper nodeMapper,EdgeMapper edgeMapper){
        this.nodeMapper=nodeMapper;
        this.edgeMapper=edgeMapper;
        Global.nodes=this.nodeMapper.selectAllNodes();
        Global.edges=this.edgeMapper.selectAllEdges();

    }
    /**
     * 邻接表生成
     * @return
     */
    @Override
    public ResponseVO InitAdjacencyTable(){
        Node callee;
        for(Node node: Global.nodes){
            if(!Global.graph.containsKey(node.getName())){
                val=new LinkedList<>();
                val.add(new GraphNode(node));
                Global.graph.put(node.getName(),val);
            }
        }
        for(Edge edge: Global.edges){
            temp=Global.graph.get(edge.getCallerName());
            callee=Global.getNodeByName(edge.getCalleeName()); //nodeMapper.selectNodeByName(edge.getCalleeName());
            temp.add(new GraphNode(callee));
        }
        return ResponseVO.buildSuccess();
    }

    /**
     * 逆邻接表生成
     * @return
     */
    @Override
    public ResponseVO InitInverseAdjacencyTable(){
        Node caller;
        for(Node node:Global.nodes){
            if(!Global.inverseGraph.containsKey(node.getName())){
                val=new LinkedList<>();
                val.add(new GraphNode(node));
                Global.inverseGraph.put(node.getName(),val);
            }
        }
        for(Edge edge:Global.edges){
            temp=Global.inverseGraph.get(edge.getCalleeName());
            caller=Global.getNodeByName(edge.getCallerName()); //nodeMapper.selectNodeByName(edge.getCallerName());
            temp.add(new GraphNode(caller));
        }
        return ResponseVO.buildSuccess();
    }
}
