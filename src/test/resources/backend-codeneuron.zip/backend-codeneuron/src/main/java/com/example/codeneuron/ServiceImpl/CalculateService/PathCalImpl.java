package com.example.codeneuron.ServiceImpl.CalculateService;

import com.example.codeneuron.PO.Global;
import com.example.codeneuron.PO.GraphNode;
import com.example.codeneuron.PO.Node;
import com.example.codeneuron.Service.CalculateService.Dynamic.PathCal;
import com.example.codeneuron.VO.ResponseVO;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PathCalImpl implements PathCal {
    /**
     * 路径查找
     * @return
     */
    private static LinkedList<GraphNode> onePath = new LinkedList<GraphNode>();
    private static Integer shortestPathLength = -1;
    public static ArrayList<ArrayList<GraphNode>> shortestPath = new ArrayList<>(); //最短路径可能有多条
    public static ArrayList<ArrayList<GraphNode>> allPaths = new ArrayList<>();
    public static String src_node = "";
    public static String target_node = "";

    @Override
    public ResponseVO searchAllPaths(){
        inputToFindPath();
        if(allPaths.size()==0){
            System.out.println("No path exists.");
            return ResponseVO.buildSuccess("没有路径");
        }
        sortByLength(allPaths);
        System.out.println("Source node: "+src_node);
        System.out.println("Target node: "+target_node);
        for(int i = 0;i<allPaths.size();i++){
            System.out.print("Path "+(i+1)+": ");
            printPath(allPaths.get(i));
        }
        return ResponseVO.buildSuccess(allPaths);
    }
    @Override
    public ResponseVO searchShortestPath() {
        inputToFindPath();
        if(shortestPath.size()==0){
            System.out.println("No path exists.");
            return ResponseVO.buildSuccess("没有路径");
        }
        System.out.println("Source node: "+src_node);
        System.out.println("Target node: "+target_node);
        for(int i = 0;i<shortestPath.size();i++){
            System.out.print("Path "+(i+1)+": ");
            printPath(shortestPath.get(i));
        }
        return ResponseVO.buildSuccess(shortestPath);
    }

    //根据函数全名进行搜索
    public static void findPath(String src, String des){
        onePath.clear();
        allPaths.clear();
        shortestPath.clear();
        shortestPathLength = -1;
        for(Node node:Global.nodes){
            node.setVisited(false);
        }
        DFS(Global.graph.get(src).getFirst(),des);
        //用后置false
        for(Node node:Global.nodes){
            node.setVisited(false);
        }
    }

    //DFS搜索
    public static void DFS(GraphNode start, String des){
        if(onePath.size()==0){
            onePath.push(start);
        }
        start.getNode().setVisited(true);
        LinkedList<GraphNode> adjacencyList = Global.graph.get(start.getNode().getName());
        for(GraphNode node:adjacencyList){
            if(node==adjacencyList.getFirst()){
                continue;
            }
            if(!node.getNode().getVisited()){
                onePath.push(node);
                if(node.getNode().getName().equals(des)){
                    ArrayList<GraphNode> rightPath = new ArrayList<>();
                    for(GraphNode pathNode:onePath){
                        rightPath.add(pathNode);
                    }
                    allPaths.add(rightPath);
                    if(shortestPathLength==-1||onePath.size()<=shortestPathLength){
                        if(onePath.size()==shortestPathLength){
                            shortestPath.add(rightPath);
                        }else {
                            shortestPathLength = onePath.size();
                            shortestPath.clear();
                            shortestPath.add(rightPath);
                        }
                    }
                }else{
                    DFS(node, des);
                    node.getNode().setVisited(false);
                }
                onePath.remove(node);
            }
        }
    }
    public static String printPath(ArrayList<GraphNode> path){
        String res = "";
        for(int i = path.size()-1;i>=0;i--){
            String tmp = "";
            if(i!=path.size()-1){
                tmp = " -- "+path.get(i).getCloseness()+" --> ";
                System.out.print(" -- "+path.get(i).getCloseness()+" --> ");
            }
            String tmpName = path.get(i).getNode().getName();
            int tmpIndex = tmpName.substring(0,tmpName.indexOf(":")).lastIndexOf(".");
            tmpName = tmpName.substring(tmpIndex+1);
            tmp += tmpName;
            System.out.print(tmpName);
            res+=tmp;
        }
        System.out.println();
        return res;
    }
    private static void inputToFindPath(){
        src_node = "";
        target_node = "";
        String input_from = "";
        String input_to = "";
        Scanner scanner = new Scanner(System.in);
        //获得出发点
        System.out.println("~ Please input source node[class/method name]:");
        if(scanner.hasNext()){
            input_from = scanner.next();
        }
        String complete_from = getCompleteFuncName(input_from);
        while(complete_from.length()==0){
            System.out.println("Cannot find the function, please input the right name.");
            input_from = scanner.next();
            complete_from = getCompleteFuncName(input_from);
        }
        //获得终点
        System.out.println("~ Please input target node[class/method name]:");
        if(scanner.hasNext()){
            input_to = scanner.next();
        }
        String complete_to = getCompleteFuncName(input_to);
        while(complete_to.length()==0){
            System.out.println("Cannot find the function, please input the right name..");
            input_to = scanner.next();
            complete_to = getCompleteFuncName(input_to);
        }
        src_node = complete_from;
        target_node = complete_to;
        findPath(complete_from,complete_to);
    }

    public static String getCompleteFuncName(String func){
        ArrayList<String> all_matched_funcs = new ArrayList<String>();
        String tmp;
        for(int i = 0; i< Global.nodes.size(); i++){
            tmp = Global.nodes.get(i).getName();
//            tmp = tmp.substring(tmp.indexOf(":")+1,tmp.indexOf("("));
            if(tmp.indexOf(func)!=-1){
                all_matched_funcs.add(Global.nodes.get(i).getName());
            }
        }
        //对重名函数询问
        if(all_matched_funcs.size()==1) {
            return all_matched_funcs.get(0);
        }
        if(all_matched_funcs.size()==0){
            return "";
        }
        System.out.println("----------------------------Search Result----------------------------");
        System.out.println();
        for(int i = 0;i<all_matched_funcs.size();i++){
            System.out.println((i+1)+": "+all_matched_funcs.get(i));
        }
        System.out.println();
        System.out.println("~ Please input the number of the node you choose:");
        Scanner scanner = new Scanner(System.in);
        int index = 0;
        while(true) {
            if (scanner.hasNext()) {
                index = Integer.parseInt(scanner.next());
            }
            if (index <= all_matched_funcs.size() && index >= 1) {
                break;
            }else{
                System.out.println("~ Please input the right number.");
            }
        }
        return all_matched_funcs.get(index-1);
    }

    public void sortByLength(ArrayList<ArrayList<GraphNode>> paths){
        Comparator c = new Comparator<ArrayList<GraphNode>>() {
            @Override
            public int compare(ArrayList<GraphNode> a1, ArrayList<GraphNode> a2) {
                if(a1.size()>a2.size()){
                    return 1;
                }else{
                    return -1;
                }
            }
        };
        paths.sort(c);
    }

}
