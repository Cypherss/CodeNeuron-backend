package com.example.codeneuron.Service.InitGraph;

import com.example.codeneuron.VO.ResponseVO;

public interface InitGraph {
    /**
     * 邻接表生成
     * @return
     */
    public ResponseVO InitAdjacencyTable();

    /**
     * 逆邻接表生成
     * @return
     */
    public ResponseVO InitInverseAdjacencyTable();
}
