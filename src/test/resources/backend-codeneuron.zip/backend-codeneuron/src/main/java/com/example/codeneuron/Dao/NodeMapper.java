package com.example.codeneuron.Dao;

import com.example.codeneuron.PO.Node;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Service;

import java.util.List;


@Mapper
@Service
public interface NodeMapper {
    /**
     * 创建新节点
     * @param node
     * @return
     */
    public int createNewNode(Node node);

    /**
     * 删除节点
     * @param id
     * @return
     */
    public int deleteNode(int id);

    /**
     * 根据名字删除节点
     * @param name
     * @return
     */
    public int deleteNodeByName(String name);

    /**
     * 选择所有节点
     * @return
     */
    public List<Node> selectAllNodes();

    /**
     * 根据id选择节点
     * @param id
     * @return
     */
    public Node selectNodeById(int id);

    /**
     * 根据名字选择节点
     * @param name
     * @return
     */
    public Node selectNodeByName(String name);
}
