package com.example.codeneuron;

import com.example.codeneuron.PO.Global;
import com.example.codeneuron.PO.Node;
import com.example.codeneuron.Service.CalculateService.Dynamic.GraphCal;
import com.example.codeneuron.Service.CalculateService.Dynamic.PathCal;
import com.example.codeneuron.Service.InitGraph.InitGraph;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Pattern;


class input{
    final static Scanner sc = new Scanner(System.in);
}
@SpringBootApplication
public class CodeneuronApplication {
    @Autowired
    InitGraph initGraphCore;
    @Autowired
    GraphCal graphCalCore;
    @Autowired
    PathCal pathCalCore;
    static InitGraph initGraph;
    static GraphCal graphCal;
    static PathCal pathCal;

    @PostConstruct
    public void initApp(){
        initGraph=initGraphCore;
        graphCal=graphCalCore;
        pathCal=pathCalCore;

    }

    public static void main(String[] args) {
        SpringApplication.run(CodeneuronApplication.class, args);
        //Scanner scanner=new Scanner(System.in);
        String command;
        initGraph.InitAdjacencyTable();
        initGraph.InitInverseAdjacencyTable();
        graphCal.ClosenessCalculate();
        System.out.println("Number of Nodes: "+ Global.nodes.size());
        System.out.println("Number of Edges: "+Global.edges.size());
        System.out.println("Number of Initial Connected SubGraph: "+(int)graphCal.ConnectedDomainCount().getContent());
        /**
         * 命令解析
         * 命令格式为：
         * 路径查找：searchAll/searchShortest
         * 展示连通域：connectedComponent
         * 设置阈值：closenessThreshold {amount}
         */
        String ThresholdPattern="closenessThreshold ([0-9]\\d*\\.?\\d*)|(0\\.\\d*[1-9])";

        while (true){
            if(input.sc.hasNext()){
                command=input.sc.nextLine();
            }
            else{
                break;
            }
            if(command.equals("connectedComponent")){
                showConnectedDomain();
            }else if(command.equals("searchShortest")){
                pathCal.searchShortestPath();
            }else if (command.equals("searchAll")){
                pathCal.searchAllPaths();
            } else if(Pattern.matches(ThresholdPattern,command)){
                setThreshold(command);
            }else if(command.equals("exit")){
                break;
            }else {
                System.out.println("Error Command");
            }

        }
        System.out.println("end");
    }

    public static void showConnectedDomain(){
        List<Set<Node>> connectedDomain=(List<Set<Node>>)graphCal.TopologyCalculate().getContent();
        System.out.println("There are "+connectedDomain.size()+" Connected Components.");
        System.out.println();
        int numDomain=1;
        for(Set set:connectedDomain){
            System.out.println("Connected_Components_"+numDomain);
            Iterator<Node> iterator=set.iterator();
            int numNode=1;
            while (iterator.hasNext()){
                System.out.println("Node "+numNode+": "+iterator.next().getName());
                numNode++;
            }
            numDomain++;
            System.out.println();
        }
    }

    public static void setThreshold(String command){
        double threshold=Double.parseDouble(command.split(" ")[1]);
        graphCal.setThreshold(threshold);
        System.out.println("please enter connectedComponent to see details");
    }


}
