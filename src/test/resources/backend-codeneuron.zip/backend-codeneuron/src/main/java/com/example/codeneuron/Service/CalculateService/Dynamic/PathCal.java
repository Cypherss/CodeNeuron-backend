package com.example.codeneuron.Service.CalculateService.Dynamic;

import com.example.codeneuron.VO.ResponseVO;

public interface PathCal {
    /**
     * 路径查找
     * @return
     */
    public ResponseVO searchAllPaths();

    public ResponseVO searchShortestPath();
}
