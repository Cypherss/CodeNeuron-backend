package com.example.codeneuron.ServiceImpl.CalculateService;

import com.example.codeneuron.PO.Global;
import com.example.codeneuron.PO.GraphNode;
import com.example.codeneuron.PO.Node;
import com.example.codeneuron.Service.CalculateService.Dynamic.GraphCal;
import com.example.codeneuron.VO.ResponseVO;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class GraphCalImpl implements GraphCal {
    //阈值
    private double threshold;
    private Set<Set<Node>> connectedDomain;

    public GraphCalImpl(){
        this.threshold=0;
        connectedDomain=new HashSet<Set<Node>>();
    }

    public double getThreshold() {
        return threshold;
    }



    public Set getConnectedDomain(){ return connectedDomain; }

    @Override
    public ResponseVO setThreshold(double threshold) {
        this.threshold = threshold;
        System.out.println("set threshold "+threshold+" successfully");
        connectedDomain.clear();
        return ResponseVO.buildSuccess();
    }
    /**
     * 依赖紧密度计算
     * @return
     */
    @Override
    public ResponseVO ClosenessCalculate(){
        for(HashMap.Entry<String,LinkedList<GraphNode>> entry: Global.graph.entrySet()){
            String key=entry.getKey();
            LinkedList<GraphNode> GraphNodes=entry.getValue();
            double outdegree = Global.graph.get(key).size() - 1;
            for(GraphNode graphNode:GraphNodes){
                //if(!graphNode.getNode().equals(GraphNodes.getFirst())) {
                if(!graphNode.equals(GraphNodes.getFirst())) {
                    double  indegree = Global.inverseGraph.get(graphNode.getNode().getName()).size() - 1;
                    double edgeThreshold = 2.0 / (indegree + outdegree);
                    graphNode.setCloseness(edgeThreshold);
                }
            }
        }
        for(HashMap.Entry<String,LinkedList<GraphNode>> entryInverse: Global.inverseGraph.entrySet()){
            String key=entryInverse.getKey();
            LinkedList<GraphNode> GraphNodes=entryInverse.getValue();
            double indegree = Global.inverseGraph.get(key).size() - 1;
            for(GraphNode graphNode:GraphNodes){
                if(!graphNode.equals(GraphNodes.getFirst())) {
                    double  outdegree = Global.graph.get(graphNode.getNode().getName()).size() - 1;
                    double edgeThreshold = 2.0 / (indegree + outdegree);
                    graphNode.setCloseness(edgeThreshold);
                }
            }
        }
        return ResponseVO.buildSuccess();
    }

    /**
     * 顶点个数计算
     * @return
     */
    @Override
    public ResponseVO NodesCount(){
        int numOfNodes=Global.nodes.size();
        return ResponseVO.buildSuccess(numOfNodes);
    }

    /**
     * 边个数计算
     * @return
     */
    @Override
    public ResponseVO EdgesCount(){
        int numOfEdges=Global.edges.size();
        return ResponseVO.buildSuccess(numOfEdges);
    }

    /**
     * 连通域个数计算
     * @return
     */
    @Override
    public ResponseVO ConnectedDomainCount(){
        int numOfDomains=0;
        connectedDomain=new HashSet<Set<Node>>();
        double tempThreshold=threshold;
        threshold=0;
        for(HashMap.Entry<String,LinkedList<GraphNode>>entry: Global.graph.entrySet()){
            String key=entry.getKey();
            LinkedList<GraphNode> GraphNodes=entry.getValue();
            if(GraphNodes.getFirst().getNode().getVisited()!=true) {
                Set tempSet = new HashSet();
                connectedDomain.add(SetCalculate(tempSet, key));
                //将visited置true
                Iterator<Node> iterator=tempSet.iterator();
                while(iterator.hasNext()){
                    Node tem=iterator.next();
                    tem.setVisited(true);
                    //System.out.print(tem.getName()+",");
                }
            }
            //System.out.println();
        }
        //还原
        for(Node node:Global.nodes){
            node.setVisited(false);
        }
        threshold=tempThreshold;

        numOfDomains=connectedDomain.size();
        return ResponseVO.buildSuccess(numOfDomains);
    }

    /**
     * 获取连通域
     * @return
     */
    @Override
    public ResponseVO TopologyCalculate(){
        connectedDomain=new HashSet<Set<Node>>();
        for(HashMap.Entry<String,LinkedList<GraphNode>>entry: Global.graph.entrySet()){
            String key=entry.getKey();
            LinkedList<GraphNode> GraphNodes=entry.getValue();
            if(GraphNodes.getFirst().getNode().getVisited()!=true) {
                Set tempSet = new HashSet();
                connectedDomain.add(SetCalculate(tempSet, key));
                //将visited置true
                Iterator<Node> iterator=tempSet.iterator();
                int numTempSet=0;
                while(iterator.hasNext()){
                    numTempSet=numTempSet+1;
                    Node tempi=iterator.next();
                    tempi.setVisited(true);
                    //System.out.print(tempi.getName()+",");
                }
                if(numTempSet<2){
                    connectedDomain.remove(tempSet);
                }
            }
            //System.out.println();
        }
        //还原
        for(Node node:Global.nodes){
            node.setVisited(false);
        }
        //排序
        List<Set<Node>> orderedConnectedDomain=new ArrayList<>(connectedDomain);
        Collections.sort(orderedConnectedDomain, new Comparator<Set<Node>>() {
            @Override
            public int compare(Set<Node> o1, Set<Node> o2) {
                int diff=o1.size()-o2.size();
                if(diff>0){
                    return -1;
                }else if(diff<0){
                    return 1;
                }
                return 0;
            }
        });
        /*
        List<Set<Node>> orderedConnectedDomain=new ArrayList<>();
        int max=0;
        for(Set set:connectedDomain){
            max=max>set.size()?max:set.size();
        }
        for(int i=max;i>1;i--){
            for(Set set:connectedDomain){
                if (set.size()==i){
                    orderedConnectedDomain.add(set);
                }
            }
        }
        */
        return ResponseVO.buildSuccess(orderedConnectedDomain);
    }

    public Set SetCalculate(Set tempSet,String key){
        LinkedList<GraphNode> tempGraphNodesOne=Global.graph.get(key);
        LinkedList<GraphNode> tempGraphNodesTwo=Global.inverseGraph.get(key);
        if(tempSet.contains(Global.getNodeByName(key))){
            return tempSet;
        }
        tempSet.add(tempGraphNodesOne.getFirst().getNode());
        if(tempGraphNodesOne.size()==1&&tempGraphNodesTwo.size()==1){
            return tempSet;
        }
        for(GraphNode tempGraphNode:tempGraphNodesOne){
            //if((!tempGraphNode.getNode().equals(tempGraphNodesOne.getFirst()))&& tempGraphNode.getCloseness()>=threshold) {
            if((!tempGraphNode.equals(tempGraphNodesOne.getFirst())) && tempGraphNode.getCloseness()>=threshold) {
                key = tempGraphNode.getNode().getName();
                SetCalculate(tempSet, key);
            }
        }

        for(GraphNode tempGraphNode:tempGraphNodesTwo){
            //if((!tempGraphNode.getNode().equals(tempGraphNodesTwo.getFirst()))&& tempGraphNode.getCloseness()>=threshold) {
            if((!tempGraphNode.equals(tempGraphNodesTwo.getFirst())) && tempGraphNode.getCloseness()>=threshold) {
                key = tempGraphNode.getNode().getName();
                SetCalculate(tempSet, key);
            }
        }
        return tempSet;
    }
}
